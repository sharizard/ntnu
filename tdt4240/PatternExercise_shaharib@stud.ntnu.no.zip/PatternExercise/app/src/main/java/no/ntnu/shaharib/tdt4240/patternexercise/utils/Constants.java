package no.ntnu.shaharib.tdt4240.patternexercise.utils;

/**
 * Created by ShahariarKabir on 12.02.2015.
 */
public class Constants {

    public static int WINDOW_HEIGHT = 0;
    public static int WINDOW_WIDTH = 0;

}
