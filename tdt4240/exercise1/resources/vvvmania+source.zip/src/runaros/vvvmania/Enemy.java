package runaros.vvvmania;

public interface Enemy {

}
